Setup
Copy Crack Files to Installation path
C:\Program Files (x86)\HitPaw Object Remover
or where you installed the software